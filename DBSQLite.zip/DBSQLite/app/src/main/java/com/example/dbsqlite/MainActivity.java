
package com.example.dbsqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {

            SQLiteDatabase bancoDados = openOrCreateDatabase("app", MODE_PRIVATE, null);

            //tabela
            bancoDados.execSQL("CREATE TABLE IF NOT EXISTS nomes( id INTEGER PRIMARY KEY AUTOINCREMENT, nome VARCHAR)");

            //Inserir dados
            bancoDados.execSQL("INSERT INTO pessoas (nome) VALUES ('Marcos')");
            bancoDados.execSQL("INSERT INTO pessoas (nome) VALUES ('Ana') ");

            Cursor cursor = bancoDados.rawQuery("SELECT nome, idade FROM pessoas ", null);

            int indiceColunaNome = cursor.getColumnIndex("nome");
            int indiceColunaId = cursor.getColumnIndex("id");

            cursor.moveToFirst();

            while (cursor != null) {

                Toast.makeText(this, cursor.getString(indiceColunaNome), Toast.LENGTH_SHORT).show();


                cursor.moveToNext();
            }

        }catch(Exception e){
            e.printStackTrace();
        }

    }
}
